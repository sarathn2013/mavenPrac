package com.jenkinpractice.selenium;

import org.testng.annotations.Test;

public class MavinDemo {
	
	@Test
	public void testHello(){
		System.out.println("Welcome to Jenkins");
	}

}
